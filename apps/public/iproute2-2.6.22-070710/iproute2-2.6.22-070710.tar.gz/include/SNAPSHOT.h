static char SNAPSHOT[] = "070710";
